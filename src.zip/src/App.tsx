import React from "react";
import './App.css';
import Frontpage from "./Frontpage";

function App() {
  return (
    <div>
      <Frontpage/>
    </div>
  )
}

export default App